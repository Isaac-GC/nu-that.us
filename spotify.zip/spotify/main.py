import sys, pprint, spotipy
import spotipy.util as util
from spotipy.oauth2 import SpotifyClientCredentials
import sqlite3
from time import sleep

client_credentials_manager = SpotifyClientCredentials()
sp = spotipy.Spotify(client_credentials_manager=client_credentials_manager)

conn_songs = sqlite3.connect('songs.db')
conn_artists = sqlite3.connect('artists.db')

cs = conn_songs.cursor()
ca = conn_artists.cursor()

artist_list = cs.execute('SELECT DISTINCT artist FROM songs').fetchall()
num_artists = len(artist_list) + 1


def search(term):
	results = sp.search(q='artist:'+term, type='artist')
	item = results['artists']['items'][0]
	return item

print "%d artists in transfer list" % (num_artists)

for i, song in enumerate(artist_list):
	artist = search(song[0])
	print artist['name'], artist['uri']
	ca.execute('INSERT OR IGNORE INTO artists VALUES (?, ?)', (artist['name'], artist['uri']))
	conn_artists.commit()
	sys.stdout.write("\r%d artists out of %d transferred\r" % (i, num_artists))
	sys.stdout.flush()

conn_songs.close()
conn_artists.close()