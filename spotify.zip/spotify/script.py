import sqlite3, urllib, sys, os
from time import sleep


cwd = '/Volumes/Secondary/TempMusic'
pwd = "Smores"

def run_via_web(song, album_art):
	album_art_png = cwd + '/album_covers/' + album_art[24:] + '.png'
	urllib.urlretrieve(album_art, filename=album_art_png)
	sleep(0.5)
	os.system('echo %s|sudo -S %s' % (pwd, "spotify-ripper --cover-file-and-embed " + album_art_png + " -l " + song))

def database(name):
	conn = sqlite3.connect(name + '.db')
	print('Database initialized...')
	c = conn.cursor()

	conn.row_factory = lambda cursor, row: row[0]
	song_list = c.execute('SELECT DISTINCT title, uri, cover_art FROM songs').fetchall()
	num_songs = len(song_list)
	print('\tWriting %d songs to songs.txt...' % (num_songs))
	with open("songs.txt", 'wt') as file:
		for i, item in enumerate(song_list):
			album_art = item[2]
			song = item[1]
			file.write(song +"\n")
	print('\tDone!')
		# album_art_png = cwd + '/album_covers/' + album_art[24:] + '.png'
		# urllib.urlretrieve(album_art, filename=album_art_png)
		# sleep(0.5)
		# print("\n%s/%s\n\n", i, num_songs)
		# os.system('echo %s|sudo -S %s' % (pwd, "spotify-ripper --cover-file-and-embed " + album_art_png + " -l " + song))


	conn.commit()
	conn.close()

if __name__ == "__main__":

	if len(sys.argv) > 2:
		song = sys.argv[1]
		album_art = sys.argv[2]
		run_via_web(song, album_art)

	if len(sys.argv) == 2:
		database(sys.argv[1])

	