import sqlite3
import spotipy, sys
import spotipy.util as util
from spotipy.oauth2 import SpotifyClientCredentials

conn = sqlite3.connect('songs.db')
cs = conn.cursor()

client_credentials_manager = SpotifyClientCredentials()
sp = spotipy.Spotify(client_credentials_manager=client_credentials_manager)
sp.trace=False

def get_artist(name):
	print name
	results = sp.search(q='artist:' + name, type='artist')
	items = results['artists']['items']
	if len(items) > 0:
		return items[0]
	else:
		return None

def show_recommendations_for_artist(artist):
	results = sp.recommendations(seed_artists = [artist['id']], limit=100)
	for track in results['tracks']:
		cs.execute("INSERT OR IGNORE INTO songs VALUES (?, ?, ?, ?)", (track['artists'][0]['name'], track['name'], track['uri'], track['album']['images'][0]['url']))
		conn.commit()
		print track['name'], '-', track['artists'][0]['name']

def get_artist_tuple(name):
	results = sp.search(q='artist:' + name[0], type='artist')
	items = results['artists']['items']
	if len(items) > 0:
		return items[0]
	else:
		return None

def show_recommendations_for_artist_tuple(artist):
	name = get_artist_tuple(artist)
	results = sp.recommendations(seed_artists = [name['id']], limit=100)
	for track in results['tracks']:
		cs.execute("INSERT OR IGNORE INTO songs VALUES (?, ?, ?, ?)", (track['artists'][0]['name'], track['name'], track['uri'], track['album']['images'][0]['url']))
		conn.commit()
		print track['name'], '-', track['artists'][0]['name']

if __name__ == '__main__':
	if len(sys.argv) < 2:
		conn.row_factory = lambda cursor, row: row[0]
		artist_list = cs.execute('SELECT DISTINCT artist FROM songs ORDER BY artist DESC LIMIT 100').fetchall()
		for name in artist_list:
			show_recommendations_for_artist_tuple(name)
	else:
		name = ' '.join(sys.argv[1:])
		artist = get_artist(name)
		if artist:
			show_recommendations_for_artist(artist)
		else:
			print "Can't find that artist", name

	conn.commit()
	conn.close()
